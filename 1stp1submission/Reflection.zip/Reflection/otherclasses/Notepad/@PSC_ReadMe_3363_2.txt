Title: JAVA Notepad 2.0
Description: 	Notepad is a program which is an implementation of the most
known Notepad application in Java language, to show the many advantages in Java
like OO concept and using the powerful Java GUI Graphical User Interface.
Notepad can open, save, save As and print our documents and undo, redo,
copy, cut, paste and select All the text in the text area. It is can change the
font, style and size. This file came from Planet-Source-Code.com...the home
millions of lines of source code You can view comments on this code/and or vote
on it at:

http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3363&lngWId=2

The author may have retained certain copyrights to this code...please observe
their request and the law by reviewing all copyright conditions at the above URL.
