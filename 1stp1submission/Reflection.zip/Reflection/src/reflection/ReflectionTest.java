/**
 * 
 */
package reflection;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author nickster
 *
 */
public class ReflectionTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
