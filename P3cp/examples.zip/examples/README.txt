clean.script and doall.script are bash scripts.
clean.script cleans the directory of all but .script
and .violet files.

doall.script executes a conformance test for each
of the listed violet files.
